# Fighting Character Select

Source plugin for Unreal Engine 5.8. Provides local two-player/CPU character selection, exclusive device joining, grid/linear navigation with optional directional links, preview animation hooks, sound/button hints, theme snapshots, match handoff, and a Slate authoring studio.

## Install

1. Copy this `FightingCharacterSelect` folder into `<YourProject>/Plugins/`. Exclude generated `Binaries`, `Intermediate` and `Saved` folders when sharing the source.
2. Enable **Fighting Character Select** in Unreal's Plugins window and restart. Compile for your engine/platform with its supported C++ toolchain. This is a source plugin; the demo project's binaries are not a portable binary distribution.
3. Open **Tools → Character Selection** to access Studio.

The plugin has no dependency on the demo project's Content, GameMode, GameInstance, default map, or input configuration. It adds no project-wide settings. Native module names remain `CharacterSelection` and `CharacterSelectionEditor` to preserve serialized Blueprint parent references. Do not install alongside an older project-local copy of those modules.

For an Unreal Automation Tool packaged ZIP, extract its contents into `<YourProject>/Plugins/FightingCharacterSelect/` and retain the supplied `Binaries` and `Intermediate` precompiled files. The instruction to exclude build folders above applies to sharing the editable source workspace, not to unpacking a binary release. Packaged binaries are specific to their advertised engine version and platform.

## Create your first screen

Choose **New setup** in Studio. Leave **Starter Screen** empty to generate a basic screen plus editable slot, grid and preview Widget Blueprints. Supply a unique setup name and a `/Game/...` destination. Review the seven output assets, create them, and use Studio’s Save selected assets to save all seven, including the generated components. Add character data assets to the generated roster (unique Character IDs, available status, thumbnail/large portrait and display text). Place exactly one generated launcher in a level, then Play.

The generated screen uses native controls and engine fonts, with no bundled character art or animation tracks. Edit the component Blueprints in UMG Designer for a custom look; use Studio for layout, prompts, controls, themes, feedback and handoff. Assign preview animations or named animation styles through the preview Blueprint and Studio. Existing authored animations are never rewritten by the wizard.

For an existing design, assign **Starter Screen** instead. This creates four assets: a screen copy, layout, roster, and launcher. The copied screen preserves its widget tree and animations; referenced slot/preview classes and art remain shared. Use Content Browser's **Migrate** for an existing project's screen and dependencies before selecting it in another project. Copying this plugin does not copy project artwork.

Created assets are unsaved and never overwrite existing packages. All seven basic destinations are checked before creation. Inspect partial results if creation fails; the wizard does not delete existing content.

## Modules and integration

* `CharacterSelection` — runtime UMG widgets, data assets, navigation, local device session and GameInstance match subsystem. C++ consumers add this module to their Build.cs dependencies.
* `CharacterSelectionEditor` — editor-only Studio, asset creation, validation and previews. Game targets must not depend on it.

Call `InitializeCharacterSelect` with a registry/layout when hosting the screen yourself. The generated launcher already does this. Optional match handoff stores both selections; the consuming game supplies fighter spawning, possession, gameplay input routing and map cooking. The plugin does not implement networking or persistent save games.

The original demo assets remain under the host project's `Content/CharacterSelect`; they are not part of this plugin. Redistribution/licensing of those assets is a separate decision. No distribution license has been selected for this source yet.

## Verification

`CharacterSelection.Plugin.BasicStarter` creates and compiles a complete setup without demo assets, initializes its screen/components and checks collision protection. Core navigation/session tests also use in-memory data. The full `CharacterSelection.` suite includes integration tests loading the original demo Blueprints, including their animation bindings; run that full suite in the demo host.

Supported/verified engine baseline: UE 5.8 on Windows. Other engine versions and platforms require their own build and device checks. Release packaging, visual review of the basic starter, cooked map travel and physical controller testing are separate from headless automation.

See [release acceptance checklist](RELEASE_CHECKLIST.md) for the release gates. The repository's `Tools/Verify-CharacterSelectRelease.ps1` and `Tests/ReleaseHost` provide repeatable package, installation, fixture, cook and simulated travel checks.
