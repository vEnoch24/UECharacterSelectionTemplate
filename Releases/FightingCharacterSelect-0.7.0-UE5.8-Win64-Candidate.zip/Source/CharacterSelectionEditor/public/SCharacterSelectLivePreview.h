#pragma once
#include "CoreMinimal.h"
#include "Widgets/SCompoundWidget.h"
#include "UObject/StrongObjectPtr.h"
#include "Core/CharacterSelectionController.h"

class UWidgetBlueprint;
class UCharacterSelectRegistry;
class UCharacterSelectLayoutData;
class SBox;

/** No viewport, input processor, or gameplay world is created by this preview. */
class SCharacterSelectLivePreview : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SCharacterSelectLivePreview) {} SLATE_END_ARGS()
	void Construct(const FArguments& Args);
	virtual ~SCharacterSelectLivePreview() override;
	void SetAssets(UWidgetBlueprint* Screen, UCharacterSelectRegistry* Registry, UCharacterSelectLayoutData* Layout);
	void Refresh();
	virtual void Tick(const FGeometry& Geometry, double Time, float Delta) override;
private:
	friend class FCharacterSelectLivePreviewTest;
	void DrawRoster();
	FText GetStatus() const;
	FReply Move(ECharacterSelectDirection Direction);
	TWeakObjectPtr<UWidgetBlueprint> ScreenAsset;
	TWeakObjectPtr<UCharacterSelectRegistry> RegistryAsset;
	TWeakObjectPtr<UCharacterSelectLayoutData> LayoutAsset;
	TStrongObjectPtr<UCharacterSelectionController> Controllers[2];
	FCharacterSelectGridLayout Grid;
	FVector2D Resolution = FVector2D(1280, 720);
	int32 ActivePlayer = 0;
	bool bPendingRefresh = false;
	bool bClipped = false;
	FString Problem;
	FString LinkWarnings;
	TSharedPtr<SBox> Stage;
	TArray<TSharedPtr<FSlateBrush>> Brushes;
	FDelegateHandle PropertyHandle;
};
