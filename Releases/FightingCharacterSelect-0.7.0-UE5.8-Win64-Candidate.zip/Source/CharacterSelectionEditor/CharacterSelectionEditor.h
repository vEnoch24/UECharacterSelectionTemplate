
#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"

class FSpawnTabArgs;
class SDockTab;

class FCharacterSelectionEditorModule : public IModuleInterface
{
public:
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

private:
	static const FName CharacterSelectionEditorTabName;

	void RegisterMenus();
	void OpenCharacterSelectionEditor();

	TSharedRef<SDockTab> SpawnCharacterSelectionEditorTab(
		const FSpawnTabArgs& Args
	);
};
