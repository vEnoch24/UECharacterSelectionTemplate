#include "SCharacterSelectLivePreview.h"
#include "WidgetBlueprint.h"
#include "Blueprint/WidgetTree.h"
#include "UI/CharacterSelectWidget.h"
#include "UI/CharacterSelectGridWidget.h"
#include "Data/CharacterSelectRegistry.h"
#include "Data/CharacterSelectLayoutData.h"
#include "Data/CharacterSelectData.h"
#include "Engine/Texture2D.h"
#include "Editor.h"
#include "UObject/UObjectGlobals.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/SCanvas.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SScaleBox.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Images/SImage.h"

void SCharacterSelectLivePreview::Construct(const FArguments& Args)
{
	TSharedRef<SHorizontalBox> Controls = SNew(SHorizontalBox);
	auto Button = [&Controls](const TCHAR* Label, FOnClicked Click)
	{
		Controls->AddSlot().AutoWidth().Padding(3)[SNew(SButton).Text(FText::FromString(Label)).OnClicked(Click)];
	};
	Button(TEXT("Player 1"), FOnClicked::CreateLambda([this] { ActivePlayer = 0; DrawRoster(); return FReply::Handled(); }));
	Button(TEXT("Player 2"), FOnClicked::CreateLambda([this] { ActivePlayer = 1; DrawRoster(); return FReply::Handled(); }));
	Button(TEXT("Left"), FOnClicked::CreateLambda([this] { return Move(ECharacterSelectDirection::Left); }));
	Button(TEXT("Right"), FOnClicked::CreateLambda([this] { return Move(ECharacterSelectDirection::Right); }));
	Button(TEXT("Up"), FOnClicked::CreateLambda([this] { return Move(ECharacterSelectDirection::Up); }));
	Button(TEXT("Down"), FOnClicked::CreateLambda([this] { return Move(ECharacterSelectDirection::Down); }));
	Button(TEXT("Confirm"), FOnClicked::CreateLambda([this]
	{
		if (Controllers[ActivePlayer].IsValid()) { Controllers[ActivePlayer]->SelectCharacter(); Controllers[ActivePlayer]->ConfirmSelection(); DrawRoster(); }
		return FReply::Handled();
	}));
	Button(TEXT("Cancel"), FOnClicked::CreateLambda([this]
	{
		if (Controllers[ActivePlayer].IsValid()) { Controllers[ActivePlayer]->CancelSelection(); DrawRoster(); }
		return FReply::Handled();
	}));
	Button(TEXT("Reset"), FOnClicked::CreateLambda([this] { Refresh(); return FReply::Handled(); }));
	TSharedRef<SHorizontalBox> Sizes = SNew(SHorizontalBox);
	for (FVector2D Size : {FVector2D(1280,720), FVector2D(1920,1080), FVector2D(1024,768)})
		Sizes->AddSlot().AutoWidth().Padding(3)[SNew(SButton)
		.Text(FText::FromString(FString::Printf(TEXT("%.0f x %.0f"), Size.X, Size.Y)))
		.OnClicked_Lambda([this, Size] { Resolution = Size; DrawRoster(); return FReply::Handled(); })];
	ChildSlot[SNew(SVerticalBox)
		+ SVerticalBox::Slot().AutoHeight().Padding(8)[SNew(STextBlock).AutoWrapText(true).Text(FText::FromString(TEXT("Live layout & navigation — changes reset the preview. Click a slot or use the buttons. This treats the grid container as the full canvas, in logical UMG units. Custom screen composition, slot styling, DPI scaling, join prompts and animations require Play mode.")))]
		+ SVerticalBox::Slot().AutoHeight()[Sizes]
		+ SVerticalBox::Slot().AutoHeight()[Controls]
		+ SVerticalBox::Slot().AutoHeight().Padding(8)[SNew(STextBlock).AutoWrapText(true).Text(this, &SCharacterSelectLivePreview::GetStatus)]
		+ SVerticalBox::Slot().FillHeight(1).Padding(8)[SNew(SScaleBox).Stretch(EStretch::ScaleToFit)
			[SAssignNew(Stage, SBox).WidthOverride(Resolution.X).HeightOverride(Resolution.Y)]]];
	PropertyHandle = FCoreUObjectDelegates::OnObjectPropertyChanged.AddLambda([this](UObject*, FPropertyChangedEvent&) { bPendingRefresh = true; });
}

SCharacterSelectLivePreview::~SCharacterSelectLivePreview()
{
	FCoreUObjectDelegates::OnObjectPropertyChanged.Remove(PropertyHandle);
}

void SCharacterSelectLivePreview::SetAssets(UWidgetBlueprint* Screen, UCharacterSelectRegistry* Registry, UCharacterSelectLayoutData* Layout)
{
	ScreenAsset = Screen; RegistryAsset = Registry; LayoutAsset = Layout; Refresh();
}

void SCharacterSelectLivePreview::Tick(const FGeometry& Geometry, double Time, float Delta)
{
	SCompoundWidget::Tick(Geometry, Time, Delta);
	SetEnabled(!GEditor || !GEditor->PlayWorld);
	if (bPendingRefresh) Refresh();
}

void SCharacterSelectLivePreview::Refresh()
{
	bPendingRefresh = false;
	Controllers[0].Reset(); Controllers[1].Reset(); Problem.Reset();
	LinkWarnings.Reset();
	if (LayoutAsset.IsValid()) LinkWarnings = FString::Join(LayoutAsset->GetDirectionalLinkIssues(RegistryAsset.Get()),TEXT("\n"));
	auto* BP = ScreenAsset.Get();
	UCharacterSelectGridWidget* Template = nullptr;
	int32 Count = 0;
	if (BP && BP->WidgetTree) BP->WidgetTree->ForEachWidget([&](UWidget* W)
	{
		if (auto* G = Cast<UCharacterSelectGridWidget>(W)) { Template = G; ++Count; }
	});
	if (Count != 1 || !RegistryAsset.IsValid() || !LayoutAsset.IsValid())
		Problem = TEXT("Select a screen with exactly one grid, a registry and a layout in Studio Setup.");
	else
	{
		Grid = Template->GetGridLayout();
		if (Grid.Columns < 1 || Grid.Rows < 0 || Grid.SlotSize.X <= 0 || Grid.SlotSize.Y <= 0 || Grid.SlotSpacing.X < 0 || Grid.SlotSpacing.Y < 0)
			Problem = TEXT("Correct the grid dimensions to preview this setup.");
		else
		{
			auto* Defaults = BP->GeneratedClass ? Cast<UCharacterSelectWidget>(BP->GeneratedClass->GetDefaultObject()) : nullptr;
			for (int32 P = 0; P < 2; ++P)
			{
				Controllers[P].Reset(NewObject<UCharacterSelectionController>());
				Controllers[P]->Initialize(RegistryAsset.Get(), LayoutAsset.Get(), P,
					Defaults && Defaults->PlayerConfigs.IsValidIndex(P) ? Defaults->PlayerConfigs[P].InitialFocusIndex : INDEX_NONE);
			}
			const int32 N = Controllers[0]->GetRosterEntries().Num();
			if (Controllers[0]->GetNavigationMode() == ECharacterSelectNavigationMode::Horizontal) { Grid.Columns = FMath::Max(1,N); Grid.Rows = 1; }
			if (Controllers[0]->GetNavigationMode() == ECharacterSelectNavigationMode::Vertical) { Grid.Columns = 1; Grid.Rows = 0; }
			for (auto& C : Controllers) C->ConfigureNavigationLayout(Grid);
			if (!N) Problem = TEXT("No visible characters. Add available characters to the selected roster.");
		}
	}
	DrawRoster();
}

FReply SCharacterSelectLivePreview::Move(ECharacterSelectDirection Direction)
{
	if (Controllers[ActivePlayer].IsValid()) { Controllers[ActivePlayer]->MoveSelection(Direction); DrawRoster(); }
	return FReply::Handled();
}

FText SCharacterSelectLivePreview::GetStatus() const
{
	FString Text = FString::Printf(TEXT("Canvas %.0f x %.0f | Controlling Player %d\n"), Resolution.X, Resolution.Y, ActivePlayer+1);
	if (!LinkWarnings.IsEmpty()) Text += LinkWarnings + TEXT("\n");
	if (!Problem.IsEmpty()) return FText::FromString(Text + Problem);
	for (int32 P = 0; P < 2; ++P) if (Controllers[P].IsValid())
	{
		auto* Character = Controllers[P]->GetFocusedCharacter();
		Text += FString::Printf(TEXT("P%d: %s%s   "), P+1, Character ? *Character->DisplayName.ToString() : TEXT("No focus"), Controllers[P]->IsConfirmed() ? TEXT(" (confirmed)") : TEXT(""));
	}
	if (bClipped) Text += TEXT("\nSome slots extend beyond the canvas. Adjust slot size, spacing, placement or roster size.");
	return FText::FromString(Text);
}

void SCharacterSelectLivePreview::DrawRoster()
{
	if (!Stage) return;
	bClipped = false;
	Stage->SetContent(SNullWidget::NullWidget); Brushes.Reset();
	Stage->SetWidthOverride(Resolution.X); Stage->SetHeightOverride(Resolution.Y);
	TSharedRef<SCanvas> Canvas = SNew(SCanvas);
	Stage->SetContent(SNew(SBorder).Padding(0).BorderBackgroundColor(FLinearColor(0.035f,0.035f,0.045f))
		.Clipping(EWidgetClipping::ClipToBounds)[Canvas]);
	if (!Problem.IsEmpty() || !Controllers[0].IsValid()) return;
	const auto& Entries = Controllers[0]->GetRosterEntries();
	const int32 Rows = Grid.GetRowCount(Entries.Num());
	const FVector2D Size(Grid.Columns * Grid.SlotSize.X + (Grid.Columns-1)*Grid.SlotSpacing.X,
		Rows * Grid.SlotSize.Y + (Rows-1)*Grid.SlotSpacing.Y);
	FVector2D Anchor, Offset;
	Grid.GetPlacement(Size, Anchor, Offset);
	const FVector2D Origin = Anchor * Resolution + Offset;
	for (int32 I = 0; I < Entries.Num(); ++I)
	{
		auto* Character = Entries[I].Character.Get();
		if (!Entries[I].bVisible || !Character) continue;
		const FVector2D C = Grid.GetSlotCoordinates(I, Entries.Num());
		const FVector2D Position = Origin + C * (Grid.SlotSize + Grid.SlotSpacing);
		bClipped |= Position.X < 0 || Position.Y < 0 || Position.X + Grid.SlotSize.X > Resolution.X || Position.Y + Grid.SlotSize.Y > Resolution.Y;
		TSharedPtr<FSlateBrush> Brush = MakeShared<FSlateBrush>();
		Brush->SetResourceObject(Character->Portrait); Brush->ImageSize = Grid.SlotSize; Brushes.Add(Brush);
		FString Label;
		for (int32 P = 0; P < 2; ++P) if (Controllers[P]->GetCurrentIndex() == I) Label += FString::Printf(TEXT("P%d "), P+1);
		if (!Entries[I].bSelectable) Label += TEXT("Locked");
		const bool bFocused = Controllers[ActivePlayer]->GetCurrentIndex() == I;
		Canvas->AddSlot().Position(Position).Size(Grid.SlotSize)
		[SNew(SButton).ContentPadding(3).ButtonColorAndOpacity(bFocused ? FLinearColor(0.12f,0.4f,0.9f) : FLinearColor(0.2f,0.2f,0.2f))
			.ToolTipText(Character->DisplayName)
			.OnClicked_Lambda([this, I] { if (Controllers[ActivePlayer].IsValid()) Controllers[ActivePlayer]->FocusCharacterAtIndex(I); DrawRoster(); return FReply::Handled(); })
			[SNew(SVerticalBox)
				+ SVerticalBox::Slot().FillHeight(1)[SNew(SImage).Image(Brush.Get())]
				+ SVerticalBox::Slot().AutoHeight()[SNew(STextBlock).Text(FText::FromString(Label))]]];
	}
}
