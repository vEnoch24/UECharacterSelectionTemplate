#if WITH_DEV_AUTOMATION_TESTS
#include "Misc/AutomationTest.h"
#include "SCharacterSelectionEditor.h"
#include "WidgetBlueprint.h"
#include "UI/CharacterSelectGridWidget.h"
#include "UI/CharacterSelectPreviewWidget.h"
#include "Data/CharacterSelectLayoutData.h"
#include "Data/CharacterSelectRegistry.h"
#include "Data/CharacterSelectData.h"
#include "Data/CharacterSelectTheme.h"
#include "Editor.h"
#include "Core/CharacterSelectTestController.h"
#include "Kismet2/KismetEditorUtilities.h"

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FCharacterSelectionStudioTest, "CharacterSelection.Editor.StudioTargets", EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)
bool FCharacterSelectionStudioTest::RunTest(const FString& Parameters)
{
	auto* Blueprint = LoadObject<UWidgetBlueprint>(nullptr, TEXT("/Game/CharacterSelect/UI/Core/WBP_CharacterSelect.WBP_CharacterSelect"));
	if (!TestNotNull(TEXT("Screen Blueprint"), Blueprint)) return false;
	TSharedRef<SCharacterSelectionEditor> Studio = SNew(SCharacterSelectionEditor);
	Studio->Assets[0].Reset(Blueprint);
	Studio->Assets[1].Reset(NewObject<UCharacterSelectLayoutData>());
	auto* Registry = NewObject<UCharacterSelectRegistry>();
	Registry->Characters.Add(NewObject<UCharacterSelectData>());
	Studio->Assets[2].Reset(Registry);
	Studio->Assets[3].Reset(); Studio->Assets[4].Reset();
	Studio->Assets[5].Reset(NewObject<UCharacterSelectTheme>());
	auto* Launcher = FKismetEditorUtilities::CreateBlueprint(ACharacterSelectTestController::StaticClass(), GetTransientPackage(), MakeUniqueObjectName(GetTransientPackage(), UBlueprint::StaticClass(), TEXT("TestHandoffLauncher")), BPTYPE_Normal);
	Studio->Assets[6].Reset(Launcher);
	for (int32 Page = 1; Page <= 12; ++Page)
	{
		Studio->SelectPage(Page);
		TestTrue(*FString::Printf(TEXT("Page %d finds actual asset targets"), Page), Studio->CurrentTarget.IsValid() && Studio->CurrentTarget->Object.IsValid());
	}
	TestTrue(TEXT("Handoff target owns launcher Blueprint for saving and opening"), Studio->CurrentTarget->Blueprint.Get() == Launcher);
	Studio->SelectPage(6);
	TestTrue(TEXT("Both preview instances can be edited independently"), Studio->Targets.Num() >= 2);
	Studio->SelectPage(1);
	auto* Grid = Cast<UCharacterSelectGridWidget>(Studio->CurrentTarget->Object.Get());
	if (!TestNotNull(TEXT("Grid template resolved"), Grid)) return false;
	Studio->SynchronizeLayout();
	auto* Layout = Cast<UCharacterSelectLayoutData>(Studio->Assets[1].Get());
	TestEqual(TEXT("Explicit sync uses actual grid columns"), Layout->Columns, Grid->GetGridLayout().Columns);
	Studio->Validate();
	TestFalse(TEXT("Validation supplies feedback"), Studio->Message.IsEmpty());
	// No source assets are edited or saved by this test.
	return true;
}
#endif
