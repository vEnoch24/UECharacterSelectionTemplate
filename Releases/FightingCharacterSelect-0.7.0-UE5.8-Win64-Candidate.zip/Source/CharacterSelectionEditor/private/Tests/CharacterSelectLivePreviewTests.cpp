#if WITH_DEV_AUTOMATION_TESTS
#include "Misc/AutomationTest.h"
#include "SCharacterSelectLivePreview.h"
#include "WidgetBlueprint.h"
#include "Data/CharacterSelectLayoutData.h"
#include "Data/CharacterSelectRegistry.h"
#include "Data/CharacterSelectData.h"

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FCharacterSelectLivePreviewTest, "CharacterSelection.Editor.LiveLayoutPreview", EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)
bool FCharacterSelectLivePreviewTest::RunTest(const FString& Parameters)
{
	FCharacterSelectGridLayout Grid;
	Grid.Padding = FMargin(10,20,30,40);
	FVector2D Anchor, Offset;
	Grid.Placement = ECharacterSelectGridPlacement::BottomRight;
	Grid.GetPlacement(FVector2D(200,100), Anchor, Offset);
	TestTrue(TEXT("Bottom-right shared anchor"), Anchor == FVector2D(1,1));
	TestTrue(TEXT("Bottom-right shared offset"), Offset == FVector2D(-230,-140));
	Grid.Placement = ECharacterSelectGridPlacement::Center;
	Grid.GetPlacement(FVector2D(200,100), Anchor, Offset);
	TestTrue(TEXT("Center ignores edge padding as runtime does"), Anchor == FVector2D(0.5,0.5) && Offset == FVector2D(-100,-50));
	TStrongObjectPtr<UCharacterSelectRegistry> Registry(NewObject<UCharacterSelectRegistry>());
	TStrongObjectPtr<UCharacterSelectLayoutData> Layout(NewObject<UCharacterSelectLayoutData>());
	for (int32 I = 0; I < 3; ++I)
	{
		auto* Character = NewObject<UCharacterSelectData>(Registry.Get());
		Character->CharacterID = FName(*FString::Printf(TEXT("Preview%d"), I));
		Registry->Characters.Add(Character);
	}
	Registry->Characters[1]->Availability = ECharacterAvailability::Locked;
	Registry->Characters[2]->Availability = ECharacterAvailability::Hidden;
	auto* BP = LoadObject<UWidgetBlueprint>(nullptr, TEXT("/Game/CharacterSelect/UI/Core/WBP_CharacterSelect.WBP_CharacterSelect"));
	if (!TestNotNull(TEXT("Starter screen"), BP)) return false;
	const bool bDirty = BP->GetOutermost()->IsDirty();
	auto Preview = SNew(SCharacterSelectLivePreview);
	Preview->SetAssets(BP, Registry.Get(), Layout.Get());
	if (!TestTrue(TEXT("Preview controllers initialized"), Preview->Controllers[0].IsValid())) return false;
	TestEqual(TEXT("Uses runtime roster filtering"), Preview->Controllers[0]->GetRosterEntries().Num(), 2);
	Preview->Controllers[0]->FocusCharacterAtIndex(1);
	Preview->Controllers[0]->SelectCharacter(); Preview->Controllers[0]->ConfirmSelection();
	TestFalse(TEXT("Locked character cannot confirm"), Preview->Controllers[0]->IsConfirmed());
	Preview->Controllers[0]->FocusCharacterAtIndex(0);
	Preview->Controllers[0]->SelectCharacter(); Preview->Controllers[0]->ConfirmSelection();
	TestTrue(TEXT("Available character confirms"), Preview->Controllers[0]->IsConfirmed());
	TestFalse(TEXT("Players have independent preview state"), Preview->Controllers[1]->IsConfirmed());
	Layout->NavigationMode = ECharacterSelectNavigationMode::Vertical;
	Preview->Refresh();
	TestEqual(TEXT("Vertical normalization"), Preview->Grid.Columns, 1);
	TestFalse(TEXT("Refresh resets state"), Preview->Controllers[0]->IsConfirmed());
	Preview->Controllers[0]->FocusCharacterAtIndex(0);
	Preview->Move(ECharacterSelectDirection::Down);
	TestEqual(TEXT("Preview uses runtime navigation"), Preview->Controllers[0]->GetCurrentIndex(), 1);
	Layout->bUseDirectionalLinks = true;
	auto& Link = Layout->DirectionalLinks.Add(TEXT("Preview0")).Up;
	Link.Rule = ECharacterSelectLinkRule::Character; Link.TargetCharacterID = TEXT("Preview1");
	Preview->Refresh(); Preview->Controllers[0]->FocusCharacterAtIndex(0); Preview->Move(ECharacterSelectDirection::Up);
	TestEqual(TEXT("Preview honors directional overrides"), Preview->Controllers[0]->GetCurrentIndex(), 1);
	TestEqual(TEXT("Preview leaves screen unchanged"), BP->GetOutermost()->IsDirty(), bDirty);
	TestEqual(TEXT("Preview leaves layout dimensions unchanged"), Layout->Columns, 7);
	Preview->Resolution = FVector2D(1,1);
	Preview->DrawRoster();
	TestTrue(TEXT("Overflow is reported for a small canvas"), Preview->bClipped);
	Layout->bAllowLockedSlots = false;
	Preview->Refresh();
	TestEqual(TEXT("Locked-slot filtering refreshes"), Preview->Controllers[0]->GetRosterEntries().Num(), 1);
	TestFalse(TEXT("Preview reports unavailable link target"), Preview->LinkWarnings.IsEmpty());
	Preview->SetAssets(nullptr, nullptr, nullptr);
	TestFalse(TEXT("Missing assets clear stale controllers"), Preview->Controllers[0].IsValid());
	TestFalse(TEXT("Missing assets supply guidance"), Preview->Problem.IsEmpty());
	return true;
}
#endif
