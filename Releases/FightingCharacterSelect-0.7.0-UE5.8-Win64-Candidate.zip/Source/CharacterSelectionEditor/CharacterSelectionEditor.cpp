
#include "CharacterSelectionEditor.h"

#include "SCharacterSelectionEditor.h"

#include "Framework/Docking/TabManager.h"
#include "ToolMenus.h"
#include "Widgets/Docking/SDockTab.h"
#include "Framework/Commands/UIAction.h"
#include "Textures/SlateIcon.h"

#define LOCTEXT_NAMESPACE "CharacterSelectionEditor"

const FName FCharacterSelectionEditorModule::CharacterSelectionEditorTabName(
	TEXT("CharacterSelectionEditor")
);

void FCharacterSelectionEditorModule::StartupModule()
{
	FGlobalTabmanager::Get()->RegisterNomadTabSpawner(
		CharacterSelectionEditorTabName,
		FOnSpawnTab::CreateRaw(
			this,
			&FCharacterSelectionEditorModule::SpawnCharacterSelectionEditorTab
		)
	)
		.SetDisplayName(
			LOCTEXT(
				"CharacterSelectionEditorTabTitle",
				"Character Selection Studio"
			)
		)
		.SetTooltipText(
			LOCTEXT(
				"CharacterSelectionEditorTabTooltip",
				"Customize layout, controls, joining, prompts, previews, roster and visual widgets."
			)
		)
		.SetMenuType(ETabSpawnerMenuType::Hidden);

	UToolMenus::RegisterStartupCallback(
		FSimpleMulticastDelegate::FDelegate::CreateRaw(
			this,
			&FCharacterSelectionEditorModule::RegisterMenus
		)
	);
}

void FCharacterSelectionEditorModule::ShutdownModule()
{
	UToolMenus::UnRegisterStartupCallback(this);
	UToolMenus::UnregisterOwner(this);

	FGlobalTabmanager::Get()->UnregisterNomadTabSpawner(
		CharacterSelectionEditorTabName
	);
}

void FCharacterSelectionEditorModule::RegisterMenus()
{
	FToolMenuOwnerScoped OwnerScoped(this);

	UToolMenu* ToolsMenu = UToolMenus::Get()->ExtendMenu(
		TEXT("MainFrame.MainMenu.Tools")
	);

	if (!ToolsMenu)
	{
		return;
	}

	FToolMenuSection& Section = ToolsMenu->FindOrAddSection(
		TEXT("CharacterSelection"),
		LOCTEXT("CharacterSelectionSectionLabel", "Character Selection"),
		FToolMenuInsert(NAME_None, EToolMenuInsertType::First)
	);

	FText MenuLabel = LOCTEXT("CharacterSelectionMenuLabel", "Character Selection");
	FText MenuTooltip = LOCTEXT("CharacterSelectionMenuTooltip", "Tools for configuring the character selection system.");

	Section.AddSubMenu(
		TEXT("CharacterSelectionSubMenu"),
		MenuLabel,
		MenuTooltip,
		FNewToolMenuDelegate::CreateLambda([this](UToolMenu* SubMenu)
			{
				// Use FindOrAddSection to safeguard internal menu construction
				FToolMenuSection& SubMenuSection = SubMenu->FindOrAddSection(TEXT("CharacterSelectionTools"));

				SubMenuSection.AddMenuEntry(
					TEXT("OpenCharacterSelectionEditor"),
					LOCTEXT("OpenCharacterSelectionEditorLabel", "Character Selection Studio"),
					LOCTEXT("OpenCharacterSelectionEditorDescription", "Open the character selection configuration tool."),
					FSlateIcon(),
					FUIAction(FExecuteAction::CreateLambda([this]()
						{
							this->OpenCharacterSelectionEditor();
						}))
				);
			})
	);
}






//void FCharacterSelectionEditorModule::RegisterMenus()
//{
//	FToolMenuOwnerScoped OwnerScoped(this);
//
//	UToolMenu* ToolsMenu = UToolMenus::Get()->ExtendMenu(
//		TEXT("LevelEditor.MainMenu.Tools")
//	);
//
//	if (!ToolsMenu)
//	{
//		return;
//	}
//
//	FToolMenuSection& Section = ToolsMenu->FindOrAddSection(
//		TEXT("CharacterSelection"),
//		FToolMenuInsert(NAME_None, EToolMenuInsertType::First)
//	);
//
//	FToolMenuEntry SubMenuEntry = FToolMenuEntry::InitSubMenu(
//		TEXT("CharacterSelectionSubMenu"),
//		LOCTEXT(
//			"CharacterSelectionMenuLabel",
//			"Character Selection"
//		),
//		LOCTEXT(
//			"CharacterSelectionMenuTooltip",
//			"Tools for configuring the character selection system."
//		),
//		FNewToolMenuDelegate::CreateLambda(
//			[this](UToolMenu* SubMenu)
//			{
//				FToolMenuSection& SubMenuSection =
//					SubMenu->AddSection(
//						TEXT("CharacterSelectionTools")
//					);
//
//				SubMenuSection.AddMenuEntry(
//					TEXT("OpenCharacterSelectionEditor"),
//					LOCTEXT(
//						"OpenCharacterSelectionEditorLabel",
//						"Character Selection Studio"
//					),
//					LOCTEXT(
//						"OpenCharacterSelectionEditorDescription",
//						"Open the character selection configuration tool."
//					),
//					FSlateIcon(),
//					FUIAction(
//						FExecuteAction::CreateRaw(
//							this,
//							&FCharacterSelectionEditorModule::
//							OpenCharacterSelectionEditor
//						)
//					)
//				);
//			}
//		),
//		false,
//		FSlateIcon()
//	);
//
//	Section.AddEntry(SubMenuEntry);
//}

void FCharacterSelectionEditorModule::OpenCharacterSelectionEditor()
{
	FGlobalTabmanager::Get()->TryInvokeTab(
		CharacterSelectionEditorTabName
	);
}

TSharedRef<SDockTab>
FCharacterSelectionEditorModule::SpawnCharacterSelectionEditorTab(
	const FSpawnTabArgs& Args
)
{
	return SNew(SDockTab)
		.TabRole(ETabRole::NomadTab)
		[
			SNew(SCharacterSelectionEditor)
		];
}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(
	FCharacterSelectionEditorModule,
	CharacterSelectionEditor
)
