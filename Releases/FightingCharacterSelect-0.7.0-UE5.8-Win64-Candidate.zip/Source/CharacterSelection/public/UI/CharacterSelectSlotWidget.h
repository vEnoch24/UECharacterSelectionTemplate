#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "CharacterSelectSlotWidget.generated.h"

class UImage;
class UWidget;
class UCharacterSelectData;
class UWidgetAnimation;

UCLASS(Abstract, Blueprintable)
class CHARACTERSELECTION_API UCharacterSelectSlotWidget
	: public UUserWidget
{
	GENERATED_BODY()

public:

	// =========================================================
	// Character
	// =========================================================

	UFUNCTION(BlueprintCallable, Category = "Character Select|Slot")
	void SetCharacter(
		UCharacterSelectData* InCharacter
	);

	UFUNCTION(BlueprintPure, Category = "Character Select|Slot")
	UCharacterSelectData* GetCharacter() const;


	// =========================================================
	// Lock
	// =========================================================

	UFUNCTION(BlueprintCallable, Category = "Character Select|Slot")
	void SetLocked(
		bool bInLocked
	);

	UFUNCTION(BlueprintPure, Category = "Character Select|Slot")
	bool IsLocked() const;


	// =========================================================
	// Roster
	// =========================================================

	UFUNCTION(BlueprintCallable, Category = "Character Select|Slot")
	void SetRosterIndex(
		int32 InRosterIndex
	);

	UFUNCTION(BlueprintPure, Category = "Character Select|Slot")
	int32 GetRosterIndex() const;


	// =========================================================
	// Focus
	// =========================================================

	UFUNCTION(BlueprintCallable, Category = "Character Select|Slot")
	void SetFocusedForPlayer(
		int32 PlayerIndex,
		bool bInFocused
	);

	UFUNCTION(BlueprintPure, Category = "Character Select|Slot")
	bool IsFocusedForPlayer(
		int32 PlayerIndex
	) const;

	UFUNCTION(BlueprintPure, Category = "Character Select|Slot")
	bool IsFocusedByAnyPlayer() const;

	UFUNCTION(BlueprintPure, Category = "Character Select|Slot")
	bool IsFocusedByBothPlayers() const;


	// =========================================================
	// Selection
	// =========================================================

	UFUNCTION(BlueprintCallable, Category = "Character Select|Slot")
	void SetSelectedForPlayer(
		int32 PlayerIndex,
		bool bInSelected
	);

	UFUNCTION(BlueprintPure, Category = "Character Select|Slot")
	bool IsSelectedForPlayer(
		int32 PlayerIndex
	) const;


protected:

	virtual void NativeConstruct() override;


private:

	// =========================================================
	// Visual Refresh
	// =========================================================

	void RefreshCharacterVisual();

	void RefreshVisualState();


	// =========================================================
	// Focus Animations
	// =========================================================

	void PlayFocusAnimationForPlayer(
		int32 PlayerIndex
	);

	void PlayUnfocusAnimationForPlayer(
		int32 PlayerIndex
	);


	// =========================================================
	// Selection Animations
	// =========================================================

	void PlaySelectedAnimationForPlayer(
		int32 PlayerIndex
	);

	void PlayDeselectedAnimationForPlayer(
		int32 PlayerIndex
	);


private:

	// =========================================================
	// Character
	// =========================================================

	UPROPERTY(
		BlueprintReadOnly,
		Category = "Character Select|Slot",
		meta = (AllowPrivateAccess = "true")
	)
	TObjectPtr<UCharacterSelectData> Character;


	// =========================================================
	// Focus State
	// =========================================================

	/**
	 * Source of truth for which players are currently focused
	 * on this slot.
	 *
	 * 0 = Player 1
	 * 1 = Player 2
	 */
	TSet<int32> FocusedPlayers;


	// =========================================================
	// Selection State
	// =========================================================

	/**
	 * Source of truth for which players have selected this slot.
	 *
	 * 0 = Player 1
	 * 1 = Player 2
	 */
	TSet<int32> SelectedPlayers;


	// =========================================================
	// General State
	// =========================================================

	UPROPERTY(
		BlueprintReadOnly,
		Category = "Character Select|Slot",
		meta = (AllowPrivateAccess = "true")
	)
	bool bLocked = false;

	UPROPERTY(
		BlueprintReadOnly,
		Category = "Character Select|Slot",
		meta = (AllowPrivateAccess = "true")
	)
	int32 RosterIndex = INDEX_NONE;


	// =========================================================
	// Character Visual
	// =========================================================

	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UImage> Portrait;


	// =========================================================
	// Player Focus Borders
	// =========================================================

	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UWidget> Player1FocusBorder;

	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UWidget> Player2FocusBorder;

	// =========================================================
	// Both Players Focus Border
	// =========================================================

	/**
	 * Only visible when BOTH Player 1 and Player 2 are focused
	 * on this exact slot.
	 */
	UPROPERTY(meta = (BindWidgetOptional))
	TObjectPtr<UWidget> BothPlayersFocusBorder;


	// =========================================================
	// Player Selection Borders
	// =========================================================

	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UWidget> Player1SelectedBorder;

	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UWidget> Player2SelectedBorder;


	// =========================================================
	// Lock
	// =========================================================

	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UWidget> LockOverlay;


	// =========================================================
	// Player 1 Focus Animations
	// =========================================================

	UPROPERTY(
		Transient,
		meta = (BindWidgetAnimOptional)
	)
	TObjectPtr<UWidgetAnimation> Player1FocusAnimation;

	UPROPERTY(
		Transient,
		meta = (BindWidgetAnimOptional)
	)
	TObjectPtr<UWidgetAnimation> Player1UnfocusAnimation;


	// =========================================================
	// Player 2 Focus Animations
	// =========================================================

	UPROPERTY(
		Transient,
		meta = (BindWidgetAnimOptional)
	)
	TObjectPtr<UWidgetAnimation> Player2FocusAnimation;

	UPROPERTY(
		Transient,
		meta = (BindWidgetAnimOptional)
	)
	TObjectPtr<UWidgetAnimation> Player2UnfocusAnimation;


	// =========================================================
	// Selection Animations
	// =========================================================

	UPROPERTY(
		Transient,
		meta = (BindWidgetAnimOptional)
	)
	TObjectPtr<UWidgetAnimation> SelectedAnimation;

	UPROPERTY(
		Transient,
		meta = (BindWidgetAnimOptional)
	)
	TObjectPtr<UWidgetAnimation> DeselectedAnimation;
};