#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "CharacterSelectPreviewWidget.generated.h"

class UCharacterSelectData;
class UImage;
class UTextBlock;
class UWidgetAnimation;

/** Names refer to animations authored in this preview's Widget Blueprint.
 * None skips that phase. Existing animations remain the default when no style is selected. */
USTRUCT(BlueprintType)
struct FCharacterPreviewAnimationStyle
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation")
	FName OutAnimationName = NAME_None;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation")
	FName InAnimationName = NAME_None;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation", meta = (ClampMin = "0.01"))
	float PlaybackSpeed = 1.0f;
};

UCLASS(Abstract, Blueprintable)
class CHARACTERSELECTION_API UCharacterSelectPreviewWidget
	: public UUserWidget
{
	GENERATED_BODY()

public:

	UFUNCTION(BlueprintCallable, Category = "Character Select|Preview")
	void SetCharacter(UCharacterSelectData* InCharacter);

	UFUNCTION(BlueprintPure, Category = "Character Select|Preview")
	UCharacterSelectData* GetCharacter() const;

	UFUNCTION(BlueprintCallable, Category = "Character Select|Preview")
	void ClearPreview();

	/** Add named styles in Class Defaults or on each preview instance. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Character Select|Preview|Animation")
	TMap<FName, FCharacterPreviewAnimationStyle> AnimationStyles;

	/** None uses the original CharacterChangeOut/InAnimation pair at speed 1. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Character Select|Preview|Animation")
	FName AnimationStyle = NAME_None;

	/** Takes effect on the next transition; does not interrupt the current animation. */
	UFUNCTION(BlueprintCallable, Category = "Character Select|Preview|Animation")
	bool SetAnimationStyle(FName StyleName);

protected:

	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;

private:

	void RefreshPreview();

	void UpdatePreviewContent(
		UCharacterSelectData* InCharacter
	);

	UWidgetAnimation* FindPreviewAnimation(FName AnimationName) const;
	void ResolveAnimationStyle();
	void UnbindExitAnimation();

	void PlayCharacterChangeAnimation();

	void FinishCharacterChange();

	UFUNCTION()
	void HandleCharacterChangeAnimationFinished();

private:

	UPROPERTY(BlueprintReadOnly, Category = "Character Select|Preview", meta = (AllowPrivateAccess = "true"))
	TObjectPtr<UCharacterSelectData> Character;

	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UImage> LargePortrait;

	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UTextBlock> CharacterName;

	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UTextBlock> Subtitle;

	UPROPERTY(Transient, meta = (BindWidgetAnimOptional))
	TObjectPtr<UWidgetAnimation> CharacterChangeOutAnimation;

	UPROPERTY(Transient, meta = (BindWidgetAnimOptional))
	TObjectPtr<UWidgetAnimation> CharacterChangeInAnimation;

	UPROPERTY()
	TObjectPtr<UCharacterSelectData> PendingCharacter;

	UPROPERTY(Transient)
	TObjectPtr<UWidgetAnimation> ActiveOutAnimation;
	UPROPERTY(Transient)
	TObjectPtr<UWidgetAnimation> ActiveInAnimation;
	float ActivePlaybackSpeed = 1.0f;

	bool bIsChangingCharacter = false;
	bool bIsPlayingOutAnimation = false;
};