#include "UI/CharacterSelectSlotWidget.h"

#include "Data/CharacterSelectData.h"

#include "Components/Image.h"
#include "Components/Widget.h"


// =============================================================
// Native Construct
// =============================================================

void UCharacterSelectSlotWidget::NativeConstruct()
{
	Super::NativeConstruct();

	RefreshCharacterVisual();
	RefreshVisualState();
}


// =============================================================
// Character
// =============================================================

void UCharacterSelectSlotWidget::SetCharacter(
	UCharacterSelectData* InCharacter)
{
	Character = InCharacter;

	RefreshCharacterVisual();
	RefreshVisualState();
}

UCharacterSelectData*
UCharacterSelectSlotWidget::GetCharacter() const
{
	return Character;
}


// =============================================================
// Roster
// =============================================================

void UCharacterSelectSlotWidget::SetRosterIndex(
	int32 InRosterIndex)
{
	RosterIndex = InRosterIndex;
}

int32 UCharacterSelectSlotWidget::GetRosterIndex() const
{
	return RosterIndex;
}


// =============================================================
// Lock
// =============================================================

void UCharacterSelectSlotWidget::SetLocked(
	bool bInLocked)
{
	if (bLocked == bInLocked)
	{
		return;
	}

	bLocked = bInLocked;

	RefreshVisualState();
}

bool UCharacterSelectSlotWidget::IsLocked() const
{
	return bLocked;
}


// =============================================================
// Focus
// =============================================================

void UCharacterSelectSlotWidget::SetFocusedForPlayer(
	int32 PlayerIndex,
	bool bInFocused)
{
	// ---------------------------------------------------------
	// Only Player 1 and Player 2 are currently supported.
	// ---------------------------------------------------------

	if (PlayerIndex < 0 || PlayerIndex > 1)
	{
		return;
	}

	const bool bWasFocused =
		FocusedPlayers.Contains(PlayerIndex);

	// ---------------------------------------------------------
	// No actual state change.
	// ---------------------------------------------------------

	if (bWasFocused == bInFocused)
	{
		return;
	}

	// ---------------------------------------------------------
	// Capture the SLOT state before modifying it.
	// ---------------------------------------------------------

	const bool bWasFocusedByAnyPlayer =
		IsFocusedByAnyPlayer();

	const bool bWasFocusedByBothPlayers =
		IsFocusedByBothPlayers();

	// ---------------------------------------------------------
	// Modify logical state.
	// ---------------------------------------------------------

	if (bInFocused)
	{
		FocusedPlayers.Add(PlayerIndex);
	}
	else
	{
		FocusedPlayers.Remove(PlayerIndex);
	}

	// ---------------------------------------------------------
	// Calculate the new SLOT state.
	// ---------------------------------------------------------

	const bool bIsFocusedByAnyPlayer =
		IsFocusedByAnyPlayer();

	const bool bIsFocusedByBothPlayers =
		IsFocusedByBothPlayers();

	// =========================================================
	// Player-specific focus handling
	// =========================================================

	if (bInFocused)
	{
		/*
		 * This player has entered this slot.
		 *
		 * Example:
		 *
		 * NONE -> P1
		 * P2   -> BOTH
		 */
		PlayFocusAnimationForPlayer(
			PlayerIndex
		);
	}
	else
	{
		/*
		 * The player has left this slot.
		 *
		 * IMPORTANT:
		 *
		 * We only play the player's Unfocus animation if the
		 * slot is NOT still occupied by another player.
		 *
		 * Therefore:
		 *
		 * P1 + P2 -> P2
		 *
		 * does NOT play P1's UnfocusAnimation.
		 *
		 * P1 -> NONE
		 *
		 * DOES play P1's UnfocusAnimation.
		 */
		if (!bIsFocusedByAnyPlayer)
		{
			PlayUnfocusAnimationForPlayer(
				PlayerIndex
			);
		}
	}

	// =========================================================
	// Combined-player state
	// =========================================================

	/*
	 * The BothPlayersFocusBorder is NOT controlled by the
	 * individual player's animation.
	 *
	 * It represents a pure derived state:
	 *
	 *     P1 == focused
	 * AND P2 == focused
	 */

	if (!bWasFocusedByBothPlayers &&
		bIsFocusedByBothPlayers)
	{
		/*
		 * We have transitioned:
		 *
		 * P1 -> BOTH
		 * or
		 * P2 -> BOTH
		 *
		 * The border itself is made visible by
		 * RefreshVisualState().
		 */
	}

	if (bWasFocusedByBothPlayers &&
		!bIsFocusedByBothPlayers)
	{
		/*
		 * We have transitioned:
		 *
		 * BOTH -> P1
		 * or
		 * BOTH -> P2
		 *
		 * RefreshVisualState() will hide the combined border.
		 */
	}

	// =========================================================
	// Refresh final visual state
	// =========================================================

	RefreshVisualState();
}


// =============================================================
// Focus Queries
// =============================================================

bool UCharacterSelectSlotWidget::IsFocusedForPlayer(
	int32 PlayerIndex
) const
{
	return FocusedPlayers.Contains(PlayerIndex);
}

bool UCharacterSelectSlotWidget::IsFocusedByAnyPlayer() const
{
	return FocusedPlayers.Num() > 0;
}

bool UCharacterSelectSlotWidget::IsFocusedByBothPlayers() const
{
	return FocusedPlayers.Contains(0) &&
		FocusedPlayers.Contains(1);
}


// =============================================================
// Selection
// =============================================================

void UCharacterSelectSlotWidget::SetSelectedForPlayer(
	int32 PlayerIndex,
	bool bInSelected)
{
	if (PlayerIndex < 0 || PlayerIndex > 1)
	{
		return;
	}

	const bool bWasSelected =
		SelectedPlayers.Contains(PlayerIndex);

	// ---------------------------------------------------------
	// Nothing changed.
	// ---------------------------------------------------------

	if (bWasSelected == bInSelected)
	{
		return;
	}

	// ---------------------------------------------------------
	// Update logical state.
	// ---------------------------------------------------------

	if (bInSelected)
	{
		SelectedPlayers.Add(PlayerIndex);
	}
	else
	{
		SelectedPlayers.Remove(PlayerIndex);
	}

	// ---------------------------------------------------------
	// Play selection animation.
	// ---------------------------------------------------------

	if (bInSelected)
	{
		PlaySelectedAnimationForPlayer(
			PlayerIndex
		);
	}
	else
	{
		PlayDeselectedAnimationForPlayer(
			PlayerIndex
		);
	}

	RefreshVisualState();
}

bool UCharacterSelectSlotWidget::IsSelectedForPlayer(
	int32 PlayerIndex
) const
{
	return SelectedPlayers.Contains(PlayerIndex);
}


// =============================================================
// Character Visual
// =============================================================

void UCharacterSelectSlotWidget::RefreshCharacterVisual()
{
	if (!Portrait)
	{
		return;
	}

	// ---------------------------------------------------------
	// No character
	// ---------------------------------------------------------

	if (!Character)
	{
		Portrait->SetBrushFromTexture(nullptr);

		Portrait->SetVisibility(
			ESlateVisibility::Collapsed
		);

		return;
	}

	// ---------------------------------------------------------
	// No portrait
	// ---------------------------------------------------------

	if (!Character->Portrait)
	{
		Portrait->SetBrushFromTexture(nullptr);

		Portrait->SetVisibility(
			ESlateVisibility::Collapsed
		);

		return;
	}

	// ---------------------------------------------------------
	// Display portrait
	// ---------------------------------------------------------

	Portrait->SetBrushFromTexture(
		Character->Portrait
	);

	Portrait->SetVisibility(
		ESlateVisibility::Visible
	);
}


// =============================================================
// Visual State
// =============================================================

void UCharacterSelectSlotWidget::RefreshVisualState()
{
	const bool bPlayer1Focused =
		FocusedPlayers.Contains(0);

	const bool bPlayer2Focused =
		FocusedPlayers.Contains(1);

	const bool bBothPlayersFocused =
		bPlayer1Focused &&
		bPlayer2Focused;

	const bool bPlayer1Selected =
		SelectedPlayers.Contains(0);

	const bool bPlayer2Selected =
		SelectedPlayers.Contains(1);


	// =========================================================
	// Player 1 Focus
	// =========================================================

	if (Player1FocusBorder)
	{
		Player1FocusBorder->SetVisibility(
			bPlayer1Focused
			? ESlateVisibility::HitTestInvisible
			: ESlateVisibility::Collapsed
		);
	}


	// =========================================================
	// Player 2 Focus
	// =========================================================

	if (Player2FocusBorder)
	{
		Player2FocusBorder->SetVisibility(
			bPlayer2Focused
			? ESlateVisibility::HitTestInvisible
			: ESlateVisibility::Collapsed
		);
	}


	// =========================================================
	// BOTH PLAYERS FOCUS
	// =========================================================

	if (BothPlayersFocusBorder)
	{
		/*
		 * THIS IS THE IMPORTANT FIX.
		 *
		 * The combined border is visible ONLY when:
		 *
		 *     Player 1 focused
		 * AND
		 *     Player 2 focused
		 *
		 * It is NOT based on "any player".
		 */

		BothPlayersFocusBorder->SetVisibility(
			bBothPlayersFocused
			? ESlateVisibility::HitTestInvisible
			: ESlateVisibility::Collapsed
		);
	}


	// =========================================================
	// Player 1 Selection
	// =========================================================

	if (Player1SelectedBorder)
	{
		Player1SelectedBorder->SetVisibility(
			bPlayer1Selected
			? ESlateVisibility::HitTestInvisible
			: ESlateVisibility::Collapsed
		);
	}


	// =========================================================
	// Player 2 Selection
	// =========================================================

	if (Player2SelectedBorder)
	{
		Player2SelectedBorder->SetVisibility(
			bPlayer2Selected
			? ESlateVisibility::HitTestInvisible
			: ESlateVisibility::Collapsed
		);
	}


	// =========================================================
	// Lock
	// =========================================================

	if (LockOverlay)
	{
		LockOverlay->SetVisibility(
			bLocked
			? ESlateVisibility::HitTestInvisible
			: ESlateVisibility::Collapsed
		);
	}
}


// =============================================================
// Player 1 / Player 2 Focus Animations
// =============================================================

void UCharacterSelectSlotWidget::PlayFocusAnimationForPlayer(
	int32 PlayerIndex)
{
	if (PlayerIndex == 0)
	{
		if (!Player1FocusAnimation)
		{
			return;
		}

		StopAnimation(
			Player1UnfocusAnimation
		);

		StopAnimation(
			Player1FocusAnimation
		);

		PlayAnimation(
			Player1FocusAnimation
		);
	}
	else if (PlayerIndex == 1)
	{
		if (!Player2FocusAnimation)
		{
			return;
		}

		StopAnimation(
			Player2UnfocusAnimation
		);

		StopAnimation(
			Player2FocusAnimation
		);

		PlayAnimation(
			Player2FocusAnimation
		);
	}
}


void UCharacterSelectSlotWidget::PlayUnfocusAnimationForPlayer(
	int32 PlayerIndex)
{
	if (PlayerIndex == 0)
	{
		if (!Player1UnfocusAnimation)
		{
			return;
		}

		StopAnimation(
			Player1FocusAnimation
		);

		StopAnimation(
			Player1UnfocusAnimation
		);

		PlayAnimation(
			Player1UnfocusAnimation
		);
	}
	else if (PlayerIndex == 1)
	{
		if (!Player2UnfocusAnimation)
		{
			return;
		}

		StopAnimation(
			Player2FocusAnimation
		);

		StopAnimation(
			Player2UnfocusAnimation
		);

		PlayAnimation(
			Player2UnfocusAnimation
		);
	}
}


// =============================================================
// Selection Animations
// =============================================================

void UCharacterSelectSlotWidget::PlaySelectedAnimationForPlayer(
	int32 PlayerIndex)
{
	if (!SelectedAnimation)
	{
		return;
	}

	StopAnimation(
		DeselectedAnimation
	);

	StopAnimation(
		SelectedAnimation
	);

	PlayAnimation(
		SelectedAnimation
	);
}


void UCharacterSelectSlotWidget::PlayDeselectedAnimationForPlayer(
	int32 PlayerIndex)
{
	if (!DeselectedAnimation)
	{
		return;
	}

	StopAnimation(
		SelectedAnimation
	);

	StopAnimation(
		DeselectedAnimation
	);

	PlayAnimation(
		DeselectedAnimation
	);
}