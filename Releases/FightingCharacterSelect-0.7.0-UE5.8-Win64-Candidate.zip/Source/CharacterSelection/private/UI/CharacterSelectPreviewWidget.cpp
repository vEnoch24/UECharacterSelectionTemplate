#include "UI/CharacterSelectPreviewWidget.h"
#include "Data/CharacterSelectData.h"
#include "Components/Image.h"
#include "Components/TextBlock.h"
#include "Animation/WidgetAnimation.h"
#include "UObject/UnrealType.h"

void UCharacterSelectPreviewWidget::NativeConstruct()
{
	Super::NativeConstruct();
	RefreshPreview();
}

void UCharacterSelectPreviewWidget::NativeDestruct()
{
	UnbindExitAnimation();
	if (ActiveOutAnimation) StopAnimation(ActiveOutAnimation);
	if (ActiveInAnimation) StopAnimation(ActiveInAnimation);
	ActiveOutAnimation = nullptr;
	ActiveInAnimation = nullptr;
	PendingCharacter = nullptr;
	bIsChangingCharacter = false;
	bIsPlayingOutAnimation = false;
	Super::NativeDestruct();
}

bool UCharacterSelectPreviewWidget::SetAnimationStyle(FName StyleName)
{
	if (!StyleName.IsNone() && !AnimationStyles.Contains(StyleName)) return false;
	AnimationStyle = StyleName;
	return true;
}

UWidgetAnimation* UCharacterSelectPreviewWidget::FindPreviewAnimation(FName AnimationName) const
{
	if (AnimationName.IsNone()) return nullptr;
	// UMG binds animation properties using the names shown in the Animations panel.
	const FObjectPropertyBase* Property = FindFProperty<FObjectPropertyBase>(GetClass(), AnimationName);
	UWidgetAnimation* Animation = Property ? Cast<UWidgetAnimation>(Property->GetObjectPropertyValue_InContainer(this)) : nullptr;
	if (!Animation)
		UE_LOG(LogTemp, Warning, TEXT("Preview %s: animation '%s' was not found; that phase is skipped."), *GetName(), *AnimationName.ToString());
	return Animation;
}

void UCharacterSelectPreviewWidget::ResolveAnimationStyle()
{
	UnbindExitAnimation();
	UWidgetAnimation* PreviousInAnimation = ActiveInAnimation;
	ActiveOutAnimation = CharacterChangeOutAnimation;
	ActiveInAnimation = CharacterChangeInAnimation;
	ActivePlaybackSpeed = 1.0f;
	if (!AnimationStyle.IsNone())
	{
		if (const FCharacterPreviewAnimationStyle* Style = AnimationStyles.Find(AnimationStyle))
		{
			ActiveOutAnimation = FindPreviewAnimation(Style->OutAnimationName);
			ActiveInAnimation = FindPreviewAnimation(Style->InAnimationName);
			ActivePlaybackSpeed = FMath::Max(0.01f, Style->PlaybackSpeed);
		}
		else
		{
			UE_LOG(LogTemp, Warning, TEXT("Preview %s: style '%s' was not found; using original animations."), *GetName(), *AnimationStyle.ToString());
		}
	}
	// A different style must not leave the previous style's enter tracks running.
	if (PreviousInAnimation && PreviousInAnimation != ActiveInAnimation) StopAnimation(PreviousInAnimation);
}

void UCharacterSelectPreviewWidget::UnbindExitAnimation()
{
	if (!ActiveOutAnimation) return;
	FWidgetAnimationDynamicEvent Delegate;
	Delegate.BindDynamic(this, &UCharacterSelectPreviewWidget::HandleCharacterChangeAnimationFinished);
	UnbindFromAnimationFinished(ActiveOutAnimation, Delegate);
}

void UCharacterSelectPreviewWidget::SetCharacter(UCharacterSelectData* InCharacter)
{
	// Keep the latest request, including nullptr or a return to the outgoing character.
	if (bIsChangingCharacter)
	{
		PendingCharacter = InCharacter;
		return;
	}
	if (Character == InCharacter) return;
	PendingCharacter = InCharacter;
	PlayCharacterChangeAnimation();
}

UCharacterSelectData* UCharacterSelectPreviewWidget::GetCharacter() const
{
	return Character;
}

void UCharacterSelectPreviewWidget::ClearPreview()
{
	SetCharacter(nullptr);
}

void UCharacterSelectPreviewWidget::RefreshPreview()
{
	UpdatePreviewContent(Character);
}

void UCharacterSelectPreviewWidget::UpdatePreviewContent(
	UCharacterSelectData* InCharacter)
{
	// --------------------------------------------------
	// No character
	// --------------------------------------------------

	if (!InCharacter)
	{
		if (LargePortrait)
		{
			LargePortrait->SetBrushFromTexture(nullptr);

			LargePortrait->SetVisibility(
				ESlateVisibility::Collapsed
			);
		}

		if (CharacterName)
		{
			CharacterName->SetText(
				FText::GetEmpty()
			);
		}

		if (Subtitle)
		{
			Subtitle->SetText(
				FText::GetEmpty()
			);
		}

		return;
	}

	// --------------------------------------------------
	// Large Portrait
	// --------------------------------------------------

	if (LargePortrait)
	{
		if (InCharacter->LargePortrait)
		{
			LargePortrait->SetBrushFromTexture(
				InCharacter->LargePortrait
			);

			LargePortrait->SetVisibility(
				ESlateVisibility::Visible
			);
		}
		else if (InCharacter->Portrait)
		{
			LargePortrait->SetBrushFromTexture(
				InCharacter->Portrait
			);

			LargePortrait->SetVisibility(
				ESlateVisibility::Visible
			);
		}
		else
		{
			LargePortrait->SetBrushFromTexture(nullptr);

			LargePortrait->SetVisibility(
				ESlateVisibility::Collapsed
			);
		}
	}

	// --------------------------------------------------
	// Character Name
	// --------------------------------------------------

	if (CharacterName)
	{
		CharacterName->SetText(
			InCharacter->DisplayName
		);
	}

	// --------------------------------------------------
	// Subtitle
	// --------------------------------------------------

	if (Subtitle)
	{
		Subtitle->SetText(
			InCharacter->Subtitle
		);
	}
}


void UCharacterSelectPreviewWidget::PlayCharacterChangeAnimation()
{
	if (bIsChangingCharacter) return;
	ResolveAnimationStyle();
	bIsChangingCharacter = true;
	if (ActiveOutAnimation)
	{
		bIsPlayingOutAnimation = true;
		StopAnimation(ActiveOutAnimation);
		FWidgetAnimationDynamicEvent Delegate;
		Delegate.BindDynamic(this, &UCharacterSelectPreviewWidget::HandleCharacterChangeAnimationFinished);
		BindToAnimationFinished(ActiveOutAnimation, Delegate);
		PlayAnimation(ActiveOutAnimation, 0.0f, 1, EUMGSequencePlayMode::Forward, ActivePlaybackSpeed);
		return;
	}
	FinishCharacterChange();
}

void UCharacterSelectPreviewWidget::HandleCharacterChangeAnimationFinished()
{
	if (!bIsChangingCharacter || !bIsPlayingOutAnimation) return;
	bIsPlayingOutAnimation = false;
	UnbindExitAnimation();
	FinishCharacterChange();
}

void UCharacterSelectPreviewWidget::FinishCharacterChange()
{
	Character = PendingCharacter;
	PendingCharacter = nullptr;
	RefreshPreview();
	if (ActiveInAnimation)
	{
		StopAnimation(ActiveInAnimation);
		PlayAnimation(ActiveInAnimation, 0.0f, 1, EUMGSequencePlayMode::Forward, ActivePlaybackSpeed);
	}
	bIsChangingCharacter = false;
}
