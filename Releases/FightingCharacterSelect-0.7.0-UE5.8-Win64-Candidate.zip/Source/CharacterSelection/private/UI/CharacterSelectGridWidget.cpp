#include "UI/CharacterSelectGridWidget.h"

#include "Core/CharacterSelectionController.h"
#include "UI/CharacterSelectSlotWidget.h"
#include "Types/CharacterSelectRosterTypes.h"

#include "Components/CanvasPanel.h"
#include "Components/CanvasPanelSlot.h"
#include <Blueprint/UserWidget.h>


void UCharacterSelectGridWidget::NativeConstruct()
{
	Super::NativeConstruct();
}


void UCharacterSelectGridWidget::NativeDestruct()
{
	SlotWidgets.Reset();
	UnbindControllerEvents();

	SelectionController = nullptr;

	SelectionControllers.Reset();

	Super::NativeDestruct();
}

void UCharacterSelectGridWidget::NativeTick(
	const FGeometry& MyGeometry,
	float InDeltaTime)
{
	Super::NativeTick(
		MyGeometry,
		InDeltaTime
	);

	if (!bWaitingForInitialLayout)
	{
		return;
	}

	const FVector2D GridSize =
		MyGeometry.GetLocalSize();

	if (GridSize.X <= 0.0f ||
		GridSize.Y <= 0.0f)
	{
		return;
	}

	PositionSlots(
		GridSize
	);

	bWaitingForInitialLayout = false;

	UE_LOG(
		LogTemp,
		Log,
		TEXT(
			"CharacterSelectGrid: "
			"Initial layout completed. "
			"Grid geometry: %s"
		),
		*GridSize.ToString()
	);
}

void UCharacterSelectGridWidget::InitializeGrid(
	const TArray<UCharacterSelectionController*>& InControllers)
{
	UnbindControllerEvents();

	SelectionController = nullptr;

	SelectionControllers.Reset();

	for (UCharacterSelectionController* Controller : InControllers)
	{
		if (!Controller)
		{
			continue;
		}

		SelectionControllers.Add(Controller);
	}

	if (SelectionControllers.IsEmpty())
	{
		UE_LOG(
			LogTemp,
			Warning,
			TEXT("CharacterSelectGridWidget: No valid selection controllers.")
		);

		return;
	}

	SelectionController = SelectionControllers[0];
	BindControllerEvents();

	RebuildGrid();
	RefreshLayout();
}

void UCharacterSelectGridWidget::BindControllerEvents()
{
	for (UCharacterSelectionController* Controller :
		SelectionControllers)
	{
		if (!Controller)
		{
			continue;
		}

		Controller->OnCharacterFocusChanged.AddUniqueDynamic(
			this,
			&UCharacterSelectGridWidget::HandleCharacterFocusChanged
		);

		Controller->OnCharacterSelected.AddUniqueDynamic(
			this,
			&UCharacterSelectGridWidget::HandleCharacterSelected
		);

		Controller->OnCharacterSelectionCancelled.AddUniqueDynamic(
			this,
			&UCharacterSelectGridWidget::HandleCharacterSelectionCancelled
		);

		Controller->OnCharacterSelectionConfirmed.AddUniqueDynamic(
			this,
			&UCharacterSelectGridWidget::HandleCharacterSelectionConfirmed
		);
	}
}

void UCharacterSelectGridWidget::UnbindControllerEvents()
{
	for (UCharacterSelectionController* Controller :
		SelectionControllers)
	{
		if (!Controller)
		{
			continue;
		}

		Controller->OnCharacterFocusChanged.RemoveDynamic(
			this,
			&UCharacterSelectGridWidget::HandleCharacterFocusChanged
		);

		Controller->OnCharacterSelected.RemoveDynamic(
			this,
			&UCharacterSelectGridWidget::HandleCharacterSelected
		);

		Controller->OnCharacterSelectionCancelled.RemoveDynamic(
			this,
			&UCharacterSelectGridWidget::HandleCharacterSelectionCancelled
		);

		Controller->OnCharacterSelectionConfirmed.RemoveDynamic(
			this,
			&UCharacterSelectGridWidget::HandleCharacterSelectionConfirmed
		);
	}

	SelectionControllers.Reset();
}


void UCharacterSelectGridWidget::RebuildGrid()
{
	if (!SlotContainer)
	{
		UE_LOG(
			LogTemp,
			Warning,
			TEXT("CharacterSelectGrid: RebuildGrid failed because SlotContainer is null.")
		);

		return;
	}

	if (!SlotWidgetClass)
	{
		UE_LOG(
			LogTemp,
			Warning,
			TEXT("CharacterSelectGrid: RebuildGrid failed because SlotWidgetClass is null.")
		);

		return;
	}

	SlotContainer->ClearChildren();

	SlotWidgets.Reset();

	GenerateSlots();

	RefreshSlotStates();

	bWaitingForInitialLayout = true;

	InvalidateLayoutAndVolatility();

	UE_LOG(
		LogTemp,
		Log,
		TEXT("CharacterSelectGrid: Grid rebuilt. Waiting for valid geometry.")
	);
}


//void UCharacterSelectGridWidget::GenerateSlots()
//{
//	if (!SelectionController)
//	{
//		return;
//	}
//
//	if (!SlotContainer)
//	{
//		return;
//	}
//
//	// ---------------------------------------------------------
//	// Get roster entries
//	// ---------------------------------------------------------
//
//	const TArray<FCharacterSelectRosterEntry>& RosterEntries =
//		SelectionController->GetRosterEntries();
//
//	// ---------------------------------------------------------
//	// Generate one widget for each roster entry
//	// ---------------------------------------------------------
//
//	for (const FCharacterSelectRosterEntry& Entry : RosterEntries)
//	{
//		if (!Entry.bVisible)
//		{
//			continue;
//		}
//
//		UCharacterSelectSlotWidget* SlotWidget =
//			CreateWidget<UCharacterSelectSlotWidget>(
//				this,
//				SlotWidgetClass
//			);
//
//		if (!SlotWidget)
//		{
//			continue;
//		}
//
//		SlotWidget->SetCharacter(
//			Entry.Character
//		);
//
//		SlotWidget->SetLocked(
//			!Entry.bSelectable
//		);
//
//		SlotContainer->AddChild(
//			SlotWidget
//		);
//
//		SlotWidgets.Add(
//			SlotWidget
//		);
//	}
//}

void UCharacterSelectGridWidget::GenerateSlots()
{
	if (!SelectionController)
	{
		UE_LOG(
			LogTemp,
			Warning,
			TEXT(
				"CharacterSelectGrid: "
				"SelectionController is null."
			)
		);

		return;
	}

	if (!SlotContainer)
	{
		UE_LOG(
			LogTemp,
			Warning,
			TEXT(
				"CharacterSelectGrid: "
				"SlotContainer is null."
			)
		);

		return;
	}

	const TArray<FCharacterSelectRosterEntry>& RosterEntries =
		SelectionController->GetRosterEntries();

	UE_LOG(
		LogTemp,
		Warning,
		TEXT(
			"CharacterSelectGrid: "
			"Roster contains %d entries."
		),
		RosterEntries.Num()
	);

	for (int32 Index = 0;
		Index < RosterEntries.Num();
		++Index)
	{
		const FCharacterSelectRosterEntry& Entry =
			RosterEntries[Index];

		if (!Entry.bVisible)
		{
			UE_LOG(
				LogTemp,
				Warning,
				TEXT(
					"CharacterSelectGrid: "
					"Roster entry %d is hidden."
				),
				Index
			);

			continue;
		}

		if (!Entry.Character)
		{
			UE_LOG(
				LogTemp,
				Warning,
				TEXT(
					"CharacterSelectGrid: "
					"Roster entry %d has no Character."
				),
				Index
			);

			continue;
		}

		UE_LOG(
			LogTemp,
			Warning,
			TEXT(
				"CharacterSelectGrid: "
				"Creating slot %d for %s."
			),
			Index,
			*Entry.Character.GetName()
		);

		UCharacterSelectSlotWidget* SlotWidget =
			CreateWidget<UCharacterSelectSlotWidget>(
				this,
				SlotWidgetClass
			);

		if (!SlotWidget)
		{
			UE_LOG(
				LogTemp,
				Error,
				TEXT(
					"CharacterSelectGrid: "
					"Failed to create slot %d."
				),
				Index
			);

			continue;
		}

		SlotWidget->SetCharacter(
			Entry.Character
		);

		SlotWidget->SetLocked(
			!Entry.bSelectable
		);

		SlotContainer->AddChild(
			SlotWidget
		);

		SlotWidgets.Add(
			SlotWidget
		);

		SlotWidget->SetRosterIndex(Index);
	}

	UE_LOG(
		LogTemp,
		Warning,
		TEXT(
			"CharacterSelectGrid: "
			"Created %d slot widgets."
		),
		SlotWidgets.Num()
	);
}


void UCharacterSelectGridWidget::RefreshLayout()
{
	if (SelectionController)
	{
		const ECharacterSelectNavigationMode Mode = SelectionController->GetNavigationMode();
		if (Mode == ECharacterSelectNavigationMode::Horizontal)
		{
			GridLayout.Columns = FMath::Max(1, SelectionController->GetRosterEntries().Num());
			GridLayout.Rows = 1;
		}
		else if (Mode == ECharacterSelectNavigationMode::Vertical)
		{
			GridLayout.Columns = 1;
			GridLayout.Rows = 0;
		}
	}
	for (UCharacterSelectionController* Controller : SelectionControllers)
	{
		if (Controller) Controller->ConfigureNavigationLayout(GridLayout);
	}
	if (!SlotContainer)
	{
		return;
	}

	if (SlotWidgets.Num() == 0)
	{
		return;
	}

	const FVector2D GridSize =
		GetCachedGeometry().GetLocalSize();

	if (GridSize.X <= 0.0f ||
		GridSize.Y <= 0.0f)
	{
		bWaitingForInitialLayout = true;
		return;
	}

	PositionSlots(
		GridSize
	);
}


void UCharacterSelectGridWidget::SetGridLayout(
	const FCharacterSelectGridLayout& InLayout)
{
	GridLayout = InLayout;

	GridLayout.Columns =
		FMath::Max(1, GridLayout.Columns);

	GridLayout.SlotSize.X =
		FMath::Max(1.0f, GridLayout.SlotSize.X);

	GridLayout.SlotSize.Y =
		FMath::Max(1.0f, GridLayout.SlotSize.Y);

	GridLayout.SlotSpacing.X =
		FMath::Max(0.0f, GridLayout.SlotSpacing.X);

	GridLayout.SlotSpacing.Y =
		FMath::Max(0.0f, GridLayout.SlotSpacing.Y);

	RefreshLayout();
}


const FCharacterSelectGridLayout&
UCharacterSelectGridWidget::GetGridLayout() const
{
	return GridLayout;
}


int32 UCharacterSelectGridWidget::GetCharacterCount() const
{
	return SlotWidgets.Num();
}


int32 UCharacterSelectGridWidget::CalculateRowCount(
	int32 CharacterCount
) const
{
	return GridLayout.GetRowCount(CharacterCount);
}


FVector2D UCharacterSelectGridWidget::CalculateGridSize(
	int32 CharacterCount
) const
{
	if (CharacterCount <= 0)
	{
		return FVector2D::ZeroVector;
	}

	const int32 Columns =
		FMath::Max(1, GridLayout.Columns);

	const int32 Rows =
		CalculateRowCount(CharacterCount);

	const float Width =
		(Columns * GridLayout.SlotSize.X)
		+
		(FMath::Max(0, Columns - 1)
			* GridLayout.SlotSpacing.X);

	const float Height =
		(Rows * GridLayout.SlotSize.Y)
		+
		(FMath::Max(0, Rows - 1)
			* GridLayout.SlotSpacing.Y);

	return FVector2D(
		Width,
		Height
	);
}


FVector2D UCharacterSelectGridWidget::CalculateGridOrigin(
	const FVector2D& ViewportSize,
	const FVector2D& GridSize
) const
{
	const float LeftPadding =
		GridLayout.Padding.Left;

	const float RightPadding =
		GridLayout.Padding.Right;

	const float TopPadding =
		GridLayout.Padding.Top;

	const float BottomPadding =
		GridLayout.Padding.Bottom;

	const float AvailableWidth =
		FMath::Max(
			0.0f,
			ViewportSize.X
			- LeftPadding
			- RightPadding
		);

	const float AvailableHeight =
		FMath::Max(
			0.0f,
			ViewportSize.Y
			- TopPadding
			- BottomPadding
		);

	FVector2D Origin = FVector2D::ZeroVector;

	switch (GridLayout.Placement)
	{
	case ECharacterSelectGridPlacement::Center:
	{
		Origin.X =
			LeftPadding
			+
			(AvailableWidth - GridSize.X)
			* 0.5f;

		Origin.Y =
			TopPadding
			+
			(AvailableHeight - GridSize.Y)
			* 0.5f;

		break;
	}

	case ECharacterSelectGridPlacement::TopCenter:
	{
		Origin.X =
			LeftPadding
			+
			(AvailableWidth - GridSize.X)
			* 0.5f;

		Origin.Y =
			TopPadding;

		break;
	}

	case ECharacterSelectGridPlacement::BottomCenter:
	{
		Origin.X =
			LeftPadding
			+
			(AvailableWidth - GridSize.X)
			* 0.5f;

		Origin.Y =
			ViewportSize.Y
			- BottomPadding
			- GridSize.Y;

		break;
	}

	case ECharacterSelectGridPlacement::LeftCenter:
	{
		Origin.X =
			LeftPadding;

		Origin.Y =
			TopPadding
			+
			(AvailableHeight - GridSize.Y)
			* 0.5f;

		break;
	}

	case ECharacterSelectGridPlacement::RightCenter:
	{
		Origin.X =
			ViewportSize.X
			- RightPadding
			- GridSize.X;

		Origin.Y =
			TopPadding
			+
			(AvailableHeight - GridSize.Y)
			* 0.5f;

		break;
	}

	case ECharacterSelectGridPlacement::TopLeft:
	{
		Origin.X =
			LeftPadding;

		Origin.Y =
			TopPadding;

		break;
	}

	case ECharacterSelectGridPlacement::TopRight:
	{
		Origin.X =
			ViewportSize.X
			- RightPadding
			- GridSize.X;

		Origin.Y =
			TopPadding;

		break;
	}

	case ECharacterSelectGridPlacement::BottomLeft:
	{
		Origin.X =
			LeftPadding;

		Origin.Y =
			ViewportSize.Y
			- BottomPadding
			- GridSize.Y;

		break;
	}

	case ECharacterSelectGridPlacement::BottomRight:
	{
		Origin.X =
			ViewportSize.X
			- RightPadding
			- GridSize.X;

		Origin.Y =
			ViewportSize.Y
			- BottomPadding
			- GridSize.Y;

		break;
	}

	case ECharacterSelectGridPlacement::Custom:
	default:
	{
		Origin.X =
			LeftPadding;

		Origin.Y =
			TopPadding;

		break;
	}
	}

	return Origin;
}

//void UCharacterSelectGridWidget::PositionSlots(
//	const FVector2D& ContainerSize)
//{
//	if (!SlotContainer)
//	{
//		return;
//	}
//
//	const int32 CharacterCount =
//		SlotWidgets.Num();
//
//	if (CharacterCount <= 0)
//	{
//		return;
//	}
//
//	const int32 Columns =
//		FMath::Max(
//			1,
//			GridLayout.Columns
//		);
//
//	const int32 Rows =
//		CalculateRowCount(
//			CharacterCount
//		);
//
//	if (Rows <= 0)
//	{
//		return;
//	}
//
//	const FVector2D GridSize =
//		CalculateGridSize(
//			CharacterCount
//		);
//
//	/*
//	 * The center anchor (0.5, 0.5) is our stable
//	 * coordinate origin.
//	 *
//	 * From there we calculate where the top-left
//	 * of the grid should be based on the selected
//	 * placement.
//	 */
//	FVector2D GridTopLeft =
//		-GridSize * 0.5f;
//
//	const float LeftPadding =
//		GridLayout.Padding.Left;
//
//	const float RightPadding =
//		GridLayout.Padding.Right;
//
//	const float TopPadding =
//		GridLayout.Padding.Top;
//
//	const float BottomPadding =
//		GridLayout.Padding.Bottom;
//
//	/*
//	 * Calculate the usable area after padding.
//	 */
//	const FVector2D AvailableSize =
//		FVector2D(
//			FMath::Max(
//				0.0f,
//				ContainerSize.X
//				- LeftPadding
//				- RightPadding
//			),
//
//			FMath::Max(
//				0.0f,
//				ContainerSize.Y
//				- TopPadding
//				- BottomPadding
//			)
//		);
//
//	/*
//	 * Calculate where the center of the usable area is
//	 * relative to the widget's center.
//	 */
//	const FVector2D AvailableCenterOffset =
//		FVector2D(
//			(LeftPadding - RightPadding) * 0.5f,
//
//			(TopPadding - BottomPadding) * 0.5f
//		);
//
//	/*
//	 * Placement offset relative to the center anchor.
//	 */
//	FVector2D PlacementOffset =
//		FVector2D::ZeroVector;
//
//	switch (GridLayout.Placement)
//	{
//	case ECharacterSelectGridPlacement::Center:
//	{
//		PlacementOffset =
//			AvailableCenterOffset;
//
//		break;
//	}
//
//	case ECharacterSelectGridPlacement::TopCenter:
//	{
//		PlacementOffset =
//			FVector2D(
//				AvailableCenterOffset.X,
//				-(ContainerSize.Y * 0.5f)
//				+
//				TopPadding
//				+
//				(GridSize.Y * 0.5f)
//			);
//
//		break;
//	}
//
//	case ECharacterSelectGridPlacement::BottomCenter:
//	{
//		PlacementOffset =
//			FVector2D(
//				AvailableCenterOffset.X,
//				(ContainerSize.Y * 0.5f)
//				-
//				BottomPadding
//				-
//				(GridSize.Y * 0.5f)
//			);
//
//		break;
//	}
//
//	case ECharacterSelectGridPlacement::LeftCenter:
//	{
//		PlacementOffset =
//			FVector2D(
//				-(ContainerSize.X * 0.5f)
//				+
//				LeftPadding
//				+
//				(GridSize.X * 0.5f),
//
//				AvailableCenterOffset.Y
//			);
//
//		break;
//	}
//
//	case ECharacterSelectGridPlacement::RightCenter:
//	{
//		PlacementOffset =
//			FVector2D(
//				(ContainerSize.X * 0.5f)
//				-
//				RightPadding
//				-
//				(GridSize.X * 0.5f),
//
//				AvailableCenterOffset.Y
//			);
//
//		break;
//	}
//
//	case ECharacterSelectGridPlacement::TopLeft:
//	{
//		PlacementOffset =
//			FVector2D(
//				-(ContainerSize.X * 0.5f)
//				+
//				LeftPadding
//				+
//				(GridSize.X * 0.5f),
//
//				-(ContainerSize.Y * 0.5f)
//				+
//				TopPadding
//				+
//				(GridSize.Y * 0.5f)
//			);
//
//		break;
//	}
//
//	case ECharacterSelectGridPlacement::TopRight:
//	{
//		PlacementOffset =
//			FVector2D(
//				(ContainerSize.X * 0.5f)
//				-
//				RightPadding
//				-
//				(GridSize.X * 0.5f),
//
//				-(ContainerSize.Y * 0.5f)
//				+
//				TopPadding
//				+
//				(GridSize.Y * 0.5f)
//			);
//
//		break;
//	}
//
//	case ECharacterSelectGridPlacement::BottomLeft:
//	{
//		PlacementOffset =
//			FVector2D(
//				-(ContainerSize.X * 0.5f)
//				+
//				LeftPadding
//				+
//				(GridSize.X * 0.5f),
//
//				(ContainerSize.Y * 0.5f)
//				-
//				BottomPadding
//				-
//				(GridSize.Y * 0.5f)
//			);
//
//		break;
//	}
//
//	case ECharacterSelectGridPlacement::BottomRight:
//	{
//		PlacementOffset =
//			FVector2D(
//				(ContainerSize.X * 0.5f)
//				-
//				RightPadding
//				-
//				(GridSize.X * 0.5f),
//
//				(ContainerSize.Y * 0.5f)
//				-
//				BottomPadding
//				-
//				(GridSize.Y * 0.5f)
//			);
//
//		break;
//	}
//
//	case ECharacterSelectGridPlacement::Custom:
//	default:
//	{
//		/*
//		 * Custom currently behaves like Center.
//		 *
//		 * We can later expose a FVector2D CustomOffset
//		 * for arbitrary placement.
//		 */
//		PlacementOffset =
//			AvailableCenterOffset;
//
//		break;
//	}
//	}
//
//	/*
//	 * Move the entire grid relative to the center anchor.
//	 */
//	GridTopLeft +=
//		PlacementOffset;
//
//	for (int32 Index = 0;
//		Index < SlotWidgets.Num();
//		++Index)
//	{
//		UCharacterSelectSlotWidget* SlotWidget =
//			SlotWidgets[Index];
//
//		if (!SlotWidget)
//		{
//			continue;
//		}
//
//		const int32 Row =
//			Index / Columns;
//
//		int32 Column =
//			Index % Columns;
//
//		if (GridLayout.bReverseHorizontal)
//		{
//			Column =
//				Columns - 1 - Column;
//		}
//
//		int32 ActualRow =
//			Row;
//
//		if (GridLayout.bReverseVertical)
//		{
//			ActualRow =
//				Rows - 1 - Row;
//		}
//
//		float RowOffset = 0.0f;
//
//		/*
//		 * Center an incomplete final row.
//		 */
//		if (GridLayout.bCenterIncompleteLastRow &&
//			Row == Rows - 1)
//		{
//			const int32 ItemsInLastRow =
//				CharacterCount -
//				((Rows - 1) * Columns);
//
//			if (ItemsInLastRow > 0 &&
//				ItemsInLastRow < Columns)
//			{
//				const float FullRowWidth =
//					GridSize.X;
//
//				const float LastRowWidth =
//					(
//						ItemsInLastRow *
//						GridLayout.SlotSize.X
//						)
//					+
//					(
//						FMath::Max(
//							0,
//							ItemsInLastRow - 1
//						) *
//						GridLayout.SlotSpacing.X
//						);
//
//				RowOffset =
//					(
//						FullRowWidth -
//						LastRowWidth
//						) * 0.5f;
//			}
//		}
//
//		const FVector2D LocalPosition =
//			GridTopLeft
//			+
//			FVector2D(
//				Column *
//				(
//					GridLayout.SlotSize.X +
//					GridLayout.SlotSpacing.X
//					)
//				+
//				RowOffset,
//
//				ActualRow *
//				(
//					GridLayout.SlotSize.Y +
//					GridLayout.SlotSpacing.Y
//					)
//			);
//
//		UCanvasPanelSlot* CanvasSlot =
//			Cast<UCanvasPanelSlot>(
//				SlotWidget->Slot
//			);
//
//		if (!CanvasSlot)
//		{
//			UE_LOG(
//				LogTemp,
//				Warning,
//				TEXT(
//					"CharacterSelectGrid: "
//					"Slot %d does not have a CanvasPanelSlot."
//				),
//				Index
//			);
//
//			continue;
//		}
//
//		/*
//		 * Keep every slot anchored to the center.
//		 */
//		CanvasSlot->SetAnchors(
//			FAnchors(
//				0.5f,
//				0.5f
//			)
//		);
//
//		CanvasSlot->SetAlignment(
//			FVector2D(
//				0.0f,
//				0.0f
//			)
//		);
//
//		CanvasSlot->SetPosition(
//			LocalPosition
//		);
//
//		CanvasSlot->SetSize(
//			GridLayout.SlotSize
//		);
//
//		CanvasSlot->SetZOrder(
//			Index
//		);
//	}
//}



void UCharacterSelectGridWidget::PositionSlots(const FVector2D& ContainerSize)
{
	if (!SlotContainer)
	{
		return;
	}

	const int32 CharacterCount = SelectionController ? SelectionController->GetRosterEntries().Num() : SlotWidgets.Num();

	if (CharacterCount <= 0)
	{
		return;
	}

	const int32 Columns =
		FMath::Max(1, GridLayout.Columns);

	const int32 Rows =
		CalculateRowCount(CharacterCount);

	if (Rows <= 0)
	{
		return;
	}

	const FVector2D GridSize =
		CalculateGridSize(CharacterCount);

	/*
	 * The important part of this implementation is that the
	 * CanvasPanel anchor itself determines WHERE the grid lives.
	 *
	 * The slot positions are then offsets relative to that anchor.
	 *
	 * This avoids relying on the actual pixel size of the root
	 * widget, which was causing the previous placement calculations
	 * to move the grid outside of the visible area.
	 */

	FVector2D PlacementAnchor, GridTopLeft;
	GridLayout.GetPlacement(GridSize, PlacementAnchor, GridTopLeft);

	/*
	 * Place every slot relative to the selected anchor.
	 */

	for (int32 Index = 0;
		Index < SlotWidgets.Num();
		++Index)
	{
		UCharacterSelectSlotWidget* SlotWidget =
			SlotWidgets[Index];

		if (!SlotWidget)
		{
			continue;
		}

		const FVector2D Coordinates = GridLayout.GetSlotCoordinates(SlotWidget->GetRosterIndex(), CharacterCount);
		const FVector2D SlotPosition = GridTopLeft + FVector2D(
			Coordinates.X * (GridLayout.SlotSize.X + GridLayout.SlotSpacing.X),
			Coordinates.Y * (GridLayout.SlotSize.Y + GridLayout.SlotSpacing.Y));

		UCanvasPanelSlot* CanvasSlot =
			Cast<UCanvasPanelSlot>(
				SlotWidget->Slot
			);

		if (!CanvasSlot)
		{
			continue;
		}

		/*
		 * The anchor is now responsible for positioning
		 * the entire grid inside SlotContainer.
		 */
		CanvasSlot->SetAnchors(
			FAnchors(
				PlacementAnchor.X,
				PlacementAnchor.Y
			)
		);

		/*
		 * Top-left alignment means SlotPosition is the
		 * actual top-left corner of this slot.
		 */
		CanvasSlot->SetAlignment(
			FVector2D(0.0f, 0.0f)
		);

		CanvasSlot->SetPosition(
			SlotPosition
		);

		CanvasSlot->SetSize(
			GridLayout.SlotSize
		);

		CanvasSlot->SetZOrder(
			Index
		);
	}
}


void UCharacterSelectGridWidget::RefreshSlotStates()
{
	if (SelectionControllers.Num() == 0)
	{
		return;
	}

	// =========================================================
	// Update every player's state independently.
	// =========================================================

	for (UCharacterSelectionController* Controller :
		SelectionControllers)
	{
		if (!Controller)
		{
			continue;
		}

		const int32 PlayerIndex =
			Controller->GetPlayerIndex();

		if (PlayerIndex < 0)
		{
			continue;
		}

		const int32 CurrentIndex =
			Controller->GetCurrentIndex();

		const int32 SelectedIndex =
			Controller->GetSelectionState()
			.SelectedCharacterIndex;

		const TArray<FCharacterSelectRosterEntry>& RosterEntries =
			Controller->GetRosterEntries();


		// =====================================================
		// Update slots
		// =====================================================

		for (int32 Index = 0;
			Index < SlotWidgets.Num();
			++Index)
		{
			UCharacterSelectSlotWidget* SlotWidget =
				SlotWidgets[Index];

			if (!SlotWidget)
			{
				continue;
			}

			if (!RosterEntries.IsValidIndex(Index))
			{
				continue;
			}

			const FCharacterSelectRosterEntry& Entry =
				RosterEntries[Index];


			// -------------------------------------------------
			// Player-specific focus
			// -------------------------------------------------

			SlotWidget->SetFocusedForPlayer(
				PlayerIndex,
				!InactivePlayers.Contains(PlayerIndex) && SlotWidget->GetRosterIndex() == CurrentIndex
			);


			// -------------------------------------------------
			// Player-specific selection
			// -------------------------------------------------

			SlotWidget->SetSelectedForPlayer(
				PlayerIndex,
				!InactivePlayers.Contains(PlayerIndex) && SlotWidget->GetRosterIndex() == SelectedIndex
			);


			// -------------------------------------------------
			// Shared slot state
			// -------------------------------------------------

			SlotWidget->SetLocked(
				!Entry.bSelectable
			);
		}
	}
}

//void UCharacterSelectGridWidget::HandleCharacterFocusChanged(
//	UCharacterSelectionController* Controller,
//	UCharacterSelectData* Character)
//{
//	if (Controller != SelectionController)
//	{
//		return;
//	}
//
//	if (!SelectionController)
//	{
//		return;
//	}
//
//	const int32 FocusedIndex =
//		SelectionController->GetCurrentIndex();
//
//	//UE_LOG(
//	//	LogTemp,
//	//	Log,
//	//	TEXT(
//	//		"CharacterSelectGrid: Focus changed. Index: %d, Character: %s"
//	//	),
//	//	FocusedIndex,
//	//	Character
//	//	? *Character->CharacterID.ToString()
//	//	: TEXT("None")
//	//);
//
//	for (int32 Index = 0;
//		Index < SlotWidgets.Num();
//		++Index)
//	{
//		UCharacterSelectSlotWidget* SlotWidget =
//			SlotWidgets[Index];
//
//		if (!SlotWidget)
//		{
//			continue;
//		}
//
//		const bool bShouldBeFocused =
//			Index == FocusedIndex;
//
//		SlotWidget->SetFocused(
//			bShouldBeFocused
//		);
//	}
//}


void UCharacterSelectGridWidget::SetPlayerActive(int32 PlayerIndex, bool bActive)
{
	if (bActive) InactivePlayers.Remove(PlayerIndex);
	else InactivePlayers.Add(PlayerIndex);
	RefreshSlotStates();
}

void UCharacterSelectGridWidget::HandleCharacterFocusChanged(UCharacterSelectionController* Controller, UCharacterSelectData* Character)
{
	RefreshSlotStates();
}
void UCharacterSelectGridWidget::HandleCharacterSelected(UCharacterSelectionController* Controller, UCharacterSelectData* Character)
{
	RefreshSlotStates();
}
void UCharacterSelectGridWidget::HandleCharacterSelectionCancelled(UCharacterSelectionController* Controller)
{
	RefreshSlotStates();
}
void UCharacterSelectGridWidget::HandleCharacterSelectionConfirmed(UCharacterSelectionController* Controller)
{
	RefreshSlotStates();
}
